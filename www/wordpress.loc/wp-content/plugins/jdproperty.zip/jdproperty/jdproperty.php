<?php
/**
 * Plugin Name: jdProperty
 * Description: First Plugin
 * Version: 1.0
 * Author: Petroff
 * Licence: GPLv2 or later
 * Text Domain: jdproperty
 */
if (!defined('ABSPATH')) {
    die;
}

class jdProperty
{

    public function register()
    {

        add_action('init', [$this, 'custom_post_type']);
    }

    public function custom_post_type()
    {
        register_post_type( 'property',
            array(
                'public' => true,
                'has_archive' => true,
                'rewrite' => array('slug' => 'properties'),
                'label' => 'Property',
                'supports' => array('title', 'editor', 'thumbnail')
            )
        );
    }

    static function activation()
    {
        //hook activation
        flush_rewrite_rules();
    }

    static function deactivation()
    {
        flush_rewrite_rules();
    }
}

if (class_exists('jdProperty')) {
    $jdProperty = new jdProperty();
    $jdProperty->register();
}


register_activation_hook(__FILE__, array($jdProperty, 'activation'));
register_deactivation_hook(__FILE__, array($jdProperty, 'deactivation'));